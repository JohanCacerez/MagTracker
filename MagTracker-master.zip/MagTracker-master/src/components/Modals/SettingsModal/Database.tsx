import React from "react";

export default function Database() {
  return <div>Database</div>;
}
