import { useState } from "react";

export default function UserSettings() {
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  return (
    <form className="p-4 gap-2 flex flex-col w-80">
      <h2 className="text-text font-title">Configuracion de usuario</h2>
      <hr className="border-divider mb-2" />
      <h2>Cambiar contraseña</h2>
      <input
        type="password"
        placeholder="Contraseña"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="p-2 border rounded font-code"
      />
      <input
        type="password"
        placeholder="Nueva contraseña"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
        className="p-2 border rounded font-code"
      />
      <button
        type="submit"
        className=" btn bg-blue-500 text-white p-2 rounded hover:bg-blue-600 disabled:opacity-50"
      >
        Cambiar contraseña
      </button>
    </form>
  );
}
