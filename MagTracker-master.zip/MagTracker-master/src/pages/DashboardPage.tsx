import React from "react";

export default function DashboardPage() {
  return (
    <>
      <h1>DashboardPage</h1>
    </>
  );
}
