import React from "react";

export default function DollieDetailPage() {
  return <div>DollieDetailPage</div>;
}
