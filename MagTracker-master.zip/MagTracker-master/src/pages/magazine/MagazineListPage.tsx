import React from "react";

export default function MagazineListPage() {
  return (
    <>
      <div>
        <h1 className="text-text font-title">Magazines</h1>
      </div>
    </>
  );
}
