import React from "react";

export default function MagazineDetailPage() {
  return <div>MagazineDetailPage</div>;
}
