"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("electronAPI", {
  magazines: {
    get: () => electron.ipcRenderer.invoke("magazines:get"),
    add: (magazine) => electron.ipcRenderer.invoke("magazines:add", magazine)
  },
  users: {
    create: (user) => electron.ipcRenderer.invoke("users:add", user),
    auth: (user) => electron.ipcRenderer.invoke("users:auth", user),
    delete: (userId) => electron.ipcRenderer.invoke("users:delete", userId)
  }
});
